const crawl = document.getElementsByClassName("crawl")[0];
crawl.addEventListener("animationend", (event) => {
    console.log("animation complete!");
});
